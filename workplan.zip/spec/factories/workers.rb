FactoryBot.define do
  factory :worker do
    name {"user2"}
    date {"12/10/2023"}
    shift {"shift-1"}
  end
end
